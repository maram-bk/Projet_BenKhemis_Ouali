import { StarcommentPipe } from './starcomment-pipe';

describe('StarcommentPipe', () => {
  it('create an instance', () => {
    const pipe = new StarcommentPipe();
    expect(pipe).toBeTruthy();
  });
});
