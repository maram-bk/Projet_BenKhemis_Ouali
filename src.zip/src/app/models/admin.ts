export interface Admin {
    email: string;
    nom: string,
    prenom: string;
}
