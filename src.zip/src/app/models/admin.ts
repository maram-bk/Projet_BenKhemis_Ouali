export interface Admin {
    id: string;
    username:string;
    password:string;
    email: string;
    nom: string,
    prenom: string;
}
