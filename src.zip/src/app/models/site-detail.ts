export interface SiteDetail {
    nom: string;
    photo: string;
    dateDecouverte: string;
    possedeMusee: boolean;
    periodeHistorique: string;
}
